# Vue 3 + TypeScript + Vite
参考
https://www.qcqx.cn/
# Axios 
[yarn add axios]
[yarn add path-browserify] 下载path
# El组件
[yarn add element-plus]

[yarn add -D unplugin-vue-components unplugin-auto-import]自动导入
[]

## el图标库


``` 
plugins: [
// ...
AutoImport({
resolvers: [ElementPlusResolver()],
}),
Components({
resolvers: [ElementPlusResolver()],
}),



```
```全局注册```
##  图片懒加载
[npm install vue-lazyload]
# Router
[yarn add vue-router]

# [markdown]
[npm install markdown-it]

[首页]

[标签]
<img src="https://typora-forlogen.oss-cn-shenzhen.aliyuncs.com/img/20200713112834.png"/>
[树洞]
<img src="./ui/树洞.png">
[音乐]

<img src="./ui/image.png">



[关于]


# 看板娘
[yarn add oh-my-live2d]


# Sess

[yarn add sass --dev]


# 可视化
[npm install @jiaminghi/data-view]




