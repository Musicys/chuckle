export interface home_cart{
    id:number,
    title:string,
    arg:string[],
    url: string,
    createdtime:Date,
    updatetime:Date
}


export interface home_arg{
    title:string,
    nuber:number
}
