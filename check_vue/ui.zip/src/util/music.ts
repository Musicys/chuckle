
import {ref} from "vue"

export const music_data=ref({
 
})