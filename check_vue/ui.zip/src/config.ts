



export default {

  /**
   * 测试-.-2024/8/17
   * 
   */

  url: "123/api/",
  aiurl: "https://api.openai-hk.com/v1/chat/completions",
  miyao: "hk-zrufo3100004129489568996f31a86feb653aa1efe8669da"



}